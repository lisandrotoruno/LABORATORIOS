/* 
 * File:   main.c
 * Author: Lisando Toru�o
 * PreLab 07
 * Created on 6 abril de 2022, 05:37 PM
 */

// PIC16F887 Configuration Bit Settings

// 'C' source line config statements

// CONFIG1
#pragma config FOSC = EXTRC_NOCLKOUT// Oscillator Selection bits (RCIO oscillator: I/O function on RA6/OSC2/CLKOUT pin, RC on RA7/OSC1/CLKIN)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled and can be enabled by SWDTEN bit of the WDTCON register)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config MCLRE = OFF      // RE3/MCLR pin function select bit (RE3/MCLR pin function is digital input, MCLR internally tied to VDD)
#pragma config CP = OFF         // Code Protection bit (Program memory code protection is disabled)
#pragma config CPD = OFF        // Data Code Protection bit (Data memory code protection is disabled)
#pragma config BOREN = OFF      // Brown Out Reset Selection bits (BOR disabled)
#pragma config IESO = OFF       // Internal External Switchover bit (Internal/External Switchover mode is disabled)
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enabled bit (Fail-Safe Clock Monitor is disabled)
#pragma config LVP = OFF        // Low Voltage Programming Enable bit (RB3 pin has digital I/O, HV on MCLR must be used for programming)

// CONFIG2
#pragma config BOR4V = BOR40V   // Brown-out Reset Selection bit (Brown-out Reset set to 4.0V)
#pragma config WRT = OFF        // Flash Program Memory Self Write Enable bits (Write protection off)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

#include <xc.h>                 
#include <stdint.h>               

/*------------------------------------------------------------------------------
 * ALIAS
 -------------------------------------------------------------------------------*/
#define INC PORTBbits.RB0           // Alias de RB0
#define DEC PORTBbits.RB1           // Alias de RB1
#define _tmr0_value 206             // Alias del N del TMR0
#define _XTAL_FREQ 500000           // Frecuencia de 500KHz
/*------------------------------------------------------------------------------
 * VARIABLES
 -------------------------------------------------------------------------------*/
uint8_t contador = 0;
uint8_t cen = 1;        //centenas
uint8_t dec = 1;        //decenas
uint8_t uni = 1;        //unidades
//"Tabla" 
uint8_t Disp[11] = {0x00, 0b00111111, 0b00000110, 0b01011011, 0b01001111, 0b01100110, 0b01101101, 0b01111101, 0b00000111, 0b01111111, 0b01101111};
/*------------------------------------------------------------------------------
 * PROTOTIPO DE FUNCIONES
 -------------------------------------------------------------------------------*/
void setup(void);

/*------------------------------------------------------------------------------
 * INTERRUPCIONES 
 -------------------------------------------------------------------------------*/
void __interrupt() isr (void){    
    if(INTCONbits.RBIF){            // Fue interrupci�n del PORTB
        if(!INC){                   // Verificamos si fue RB0 quien gener� la interruption
            uni++;
            contador++;
            //incremento decenas
            if(uni == 11)
            {    
                dec++;
                uni=1;
            }
            
            if(dec == 11)
            {
                cen++;
                dec=1;
                uni=1;
            }
            
            if(cen==4 && dec ==7 && uni==8)
            {
                uni=1;
                dec=1;
                cen=1;
            }       
        }
        else if(!DEC){              // Verificamos si fue RB1 quien gener� la interruption
            contador--;             // Decremento del PORTC 
            uni--;
                       
            if(uni == 0)
            {
                dec--;
                uni=10;
            }
            
            if(dec == 0)
            {
                cen--;
                dec=10;
            }
            if(cen==1 && dec==1 && uni==0)
            {
                cen=4;
                dec=7;
                uni=7;
            }        
        }
        PORTD = contador;           // PORTA es el valor de contador
        INTCONbits.RBIF = 0;        // Limpiamos bandera de interruption del PORTB
    } 
    if(T0IF){                       // Verificamos si fue Interrupci�n de TMR0
        PORTA *= 2;
        if(PORTA > 4)
            PORTA = 1;
        
    INTCONbits.T0IF = 0;            // Limpiamos bandera de TMR0
    TMR0 = _tmr0_value;
    }
    if(PORTA == 1){
        PORTC = Disp[uni];
    }
    if(PORTA == 2){
        PORTC = Disp[dec];
    }
    if(PORTA == 4){
        PORTC = Disp[cen];
    }
    return;
}

/*------------------------------------------------------------------------------
 * CICLO PRINCIPAL
 -------------------------------------------------------------------------------*/
void main(void) {
    setup();                        // Llamamos a la funci�n de configuraciones
    while(1){
        
    }
}

/*------------------------------------------------------------------------------
 * CONFIGURACI�N
 -------------------------------------------------------------------------------*/
void setup(void) {
    ANSEL = 0;
    ANSELH = 0;                 // I/O Digitales
    
    TRISA = 0;                  // PORTA COMO SALIDA -> Driver
    TRISD = 0;                  // PORTD COMO SALIDA -> Contador 8 Bits   
    TRISC = 0;                  // PORTC COMO SALIDA -> Displays
    TRISBbits.TRISB1 = 1;       // RB1 como entrada (configurada con control de bits) -> Decremento
    TRISBbits.TRISB0 = 1;       // RB0 como entrada (configurada con control de bits) -> Incremento
    
    //SETEAMOS A 0 LOS PUERTOS:
    PORTA = 1;
    PORTB = 0;
    PORTC = 0;
    PORTD = 0;
    
    //HAB. PULL-UP INTERNO
    OPTION_REGbits.nRBPU = 0;   // Habilitamos resistencias de pull-up del PORTB
    WPUB =0b00000011;           // Habilitamos resistencia de pull-up de RB0 y RB1
    
    //INTERRUCIONES CONFIG.
    INTCONbits.GIE = 1;         // Habilitamos interrupciones globales
    INTCONbits.RBIE = 1;        // Habilitamos interrupciones del PORTB
    INTCONbits.T0IE = 1;        // Habilitamos interrupciones del TMR0
    IOCBbits.IOCB0 = 1;         // Habilitamos interrupci�n por cambio de estado para RB0
    IOCBbits.IOCB1 = 1;         // Habilitamos interrupci�n por cambio de estado para RB1
    INTCONbits.RBIF = 0;        // Limpiamos bandera de interrupci�n del PORTB
    INTCONbits.T0IF = 0;        // Limpiamos bandera de TMR0
    
    //CONFIG RELOJ
    OSCCONbits.IRCF = 0b0011;    // 500 KHz
    OSCCONbits.SCS  = 1;        // Reloj Interno
        
    //CONFIG TMR0
    OPTION_REGbits.T0CS = 0;    // Trabaja como temporizador
    OPTION_REGbits.PSA = 0;     // Prescaler TMR0
    OPTION_REGbits.PS2 = 1;     // Prescaler de 1:256
    OPTION_REGbits.PS1 = 1;
    OPTION_REGbits.PS0 = 1;
}
