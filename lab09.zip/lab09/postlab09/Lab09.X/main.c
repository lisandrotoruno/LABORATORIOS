/* 
 * File:   main.c
 * Author: Lisandro Toru�o
 *
 * Created on 29 de abril de 2022, 07:32 PM
 */
// PIC16F887 Configuration Bit Settings

// 'C' source line config statements

// CONFIGURATION WORDS 1
#pragma config FOSC = INTRC_NOCLKOUT// Oscillator Selection bits (INTOSCIO oscillator: I/O function on RA6/OSC2/CLKOUT pin, I/O function on RA7/OSC1/CLKIN)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled and can be enabled by SWDTEN bit of the WDTCON register)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config MCLRE = OFF      // RE3/MCLR pin function select bit (RE3/MCLR pin function is digital input, MCLR internally tied to VDD)
#pragma config CP = OFF         // Code Protection bit (Program memory code protection is disabled)
#pragma config CPD = OFF        // Data Code Protection bit (Data memory code protection is disabled)
#pragma config BOREN = OFF      // Brown Out Reset Selection bits (BOR disabled)
#pragma config IESO = OFF       // Internal External Switchover bit (Internal/External Switchover mode is disabled)
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enabled bit (Fail-Safe Clock Monitor is disabled)
#pragma config LVP = OFF        // Low Voltage Programming Enable bit (RB3 pin has digital I/O, HV on MCLR must be used for programming)

// CONFIGURATION WORDS 1
#pragma config BOR4V = BOR40V   // Brown-out Reset Selection bit (Brown-out Reset set to 4.0V)
#pragma config WRT = OFF        // Flash Program Memory Self Write Enable bits (Write protection off)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

/*------------------------------------------------------------------------------
 * LIBRERIAS 
 ------------------------------------------------------------------------------*/
#include <xc.h>
#include <stdint.h>
#define _XTAL_FREQ 8000000
/*------------------------------------------------------------------------------
 * VARIABLES 
 ------------------------------------------------------------------------------*/
uint8_t counter;                   // VARIABLE PARA CONTADOR
uint8_t adresh_value;           // VARIABLE PARA MANIPULAR ADRESH
/*------------------------------------------------------------------------------
 * PROTOTIPO DE FUNCIONES 
 ------------------------------------------------------------------------------*/
void config_io_clk(void);
void config_tmr0(void);
void config_adc(void);
void config_pwm_motor1_2();
void config_int(void);
/*------------------------------------------------------------------------------
 * INTERRUPCIONES 
 ------------------------------------------------------------------------------*/
void __interrupt() isr (void)
{
    if(PIR1bits.ADIF)                   // BANDERA = ON --> SIGO ADELANTE
    {
        if(ADCON0bits.CHS == 5)         // ELEI� EL CANAL 5?
        {
            CCPR1L = (ADRESH>>1)+120;
            CCP1CONbits.DC1B1 = ADRESH & 0b01;
            CCP1CONbits.DC1B0 = (ADRESH>>7);
        }else if(ADCON0bits.CHS == 6)   // ELEJI� EL CANAL 6?
        {
            CCPR2L = (ADRESH>>1)+120;   // VALOR == 124
            CCP1CONbits.DC1B1 = ADRESH & 0b01;
            CCP1CONbits.DC1B0 = (ADRESH>>7);
        }else                           // SINO
        {
            adresh_value = ADRESH;
        }
        PIR1bits.ADIF = 0;
    }else if(INTCONbits.T0IF)    // T0IF ENCENDIDA SIGO ADELANTE
    {                            // SI EL CONTADOR ES MENOR QUE EL VALOR DE ADRESH, ENTONCES ENCIENDE EL RD0
        counter = counter++;
        
        if (counter >= adresh_value)
        {
            PORTDbits.RD0 = 0;
        } else
        {
            PORTDbits.RD0 = 1;
        }        
        TMR0 = 225;
        INTCONbits.T0IF = 0;   
    }
}
/*------------------------------------------------------------------------------
 * CICLO PRINCIPAL
 ------------------------------------------------------------------------------*/
void main(void) 
{
    config_io_clk();
    config_tmr0();
    config_adc();
    config_pwm_motor1_2();
    config_int();
    
    ADCON0bits.GO = 1;                       // CONVERSI�N = ACTIVADA
    while(1)
    {
        if(ADCON0bits.GO == 0)              // ULTIMA CONVERSI�N TERMINADA? S� SI, CONTINUE A LA SIGUIENTE LINEA
        {
            if(ADCON0bits.CHS == 5)         // CANAL 5 -> PASO AL 6
                ADCON0bits.CHS = 6;
            else if(ADCON0bits.CHS == 6)    // ULTIMO = CANAL 6 --> PASO AL 7
                ADCON0bits.CHS = 7;
            else                            // VUELVE AL CANAL 5
                ADCON0bits.CHS = 5;     
            __delay_us(50);                 // DELAY
            ADCON0bits.GO = 1;              // INICIA NUEVAMENTE LA CONVERSION
        }
        
    }
}
/*------------------------------------------------------------------------------
 * CONFIGURACION 
 ------------------------------------------------------------------------------*/
void config_io_clk(void)     // CONFIGURAMOS I/O Y RELOJ
{
    ANSEL   =   0b11100000;     // AN5, AN6 y AN7 ENTRADAS ANAL�GICAS
    ANSELH  =   0;              // I/O DIGITALES 
    TRISD   =   0;              // SALIDA
    PORTD   =   0;              // LIMPIAR PUERTO
 
    OSCCONbits.IRCF  = 0b111;   // 8MHz    
    OSCCONbits.SCS   = 1;       // ACTIVO RELOJ INTERNO
    return;
}

//CONFIGURACION TMR0
void config_tmr0(void)
{
    // generar  una interrupci?n  y  aumentar  contador.
    OPTION_REGbits.T0CS = 0;  // FOSC/4
    OPTION_REGbits.T0SE = 0;  // Increment on low-to-high transition on T0CKI pin
    OPTION_REGbits.PSA = 0;   // ASIGNAR VALOR DE PRESCALER AL MODULO DEL TMR0
    OPTION_REGbits.PS2 = 0;   
    OPTION_REGbits.PS1 = 0;   
    OPTION_REGbits.PS0 = 0;   // 1:2 PRESCALE  
    TMR0 = 225;               // N = 225
    return;
}
// CONFIGURACION ADC
void config_adc(void)
{
     // CONFIGURAMOS REFERENCIAS INTERNAS:
    ADCON1bits.ADFM = 0;        // JUSTIFICADO A LA IZQUIERDA
    ADCON1bits.VCFG0 = 0;       // REFERENCIA --> VDD
    ADCON1bits.VCFG1 = 0;       // REFERENCIA --> VSS
    
    // CONFIGURAMOS QUE CANAL ANALOGICO SERA NUESTRA ENTRADA:
    ADCON0bits.ADCS = 0b10;     // UTILIZAMOS FOSC/8
    ADCON0bits.CHS = 5;         // CH5 EL CANAL PRINCIPAL
    ADCON0bits.ADON = 1;        // ADC == ON
    __delay_us(50);             // DELAY DE 50us
    return;
}
// CONFIGURACION PWM --> MOTOR 1
void config_pwm_motor1_2(void)
{
    // EL PWM GENERA SE?ALES DE FRECUENCIA Y CICLO DE TRABAJO. MODULO CCP Y TIMER2, TRABAJA JUNTO COMO MODULARDOR DE ANCHO DE PULSO
    // POR UN PER�ODO QUE EST� ACARGO DE PR2 Y TMR2
    TRISCbits.TRISC2 = 1;           // RC2/CCP1 como entrada
    PR2 = 250;                      // Periodo
    CCP1CONbits.P1M = 0;
    CCP1CONbits.CCP1M = 0b1100;
    
    CCPR1L = 0b1111;                //  Duty cycle  
    CCP1CONbits.DC1B = 0;
    
    PIR1bits.TMR2IF = 0;            // TMR 2 --> 0 = No Timer2 to PR2 match occurred
    T2CONbits.T2CKPS = 0b11;        // T2CKPS<1:0> --> PRESCALER 16
    T2CONbits.TMR2ON = 1;           // TMR2 ON
                                    
    while(PIR1bits.TMR2IF == 0);
    PIR1bits.TMR2IF = 0;             // No Timer2 to PR2 match occurred
    
    TRISCbits.TRISC2 = 0;           // RC2 --> SALIDA

// CONFIGURACION PWM --> MOTOR 2
    TRISCbits.TRISC1 = 1;           // RC1/CCP2 --> LUEGO LAS IGUALAMOS A CERO.
    CCP2CONbits.CCP2M = 0b1100;     // 11xx = PWM mode.
    
    CCPR2L = 0b1111;                // 11xx = PWM mode. 
    CCP2CONbits.DC2B0 = 0;          // DC2B<1:0> --> PWM Duty Cycle Least Significant bits
    CCP2CONbits.DC2B1 = 0;
    // PWM mode:
    TRISCbits.TRISC1 = 0;           // RC1 --> SALIDA
}

// CONFIGURACION INTERRUPCIONES
void config_int(void)      
{
    INTCONbits.GIE  = 1;        // ACTIVO LAS INT GLOBALES 
    INTCONbits.PEIE = 1;        // INT. PERIFERICAS == ON
    INTCONbits.T0IE = 1;        // INTERRUPCIONES TMR0 
    INTCONbits.TMR0IF = 0;      // SE APAGA LA BANDERA DEL TMR0
    PIE1bits.ADIE = 1;          // SE ACTIVA INTERRUPCIONES PARA EL TMR0.
    PIR1bits.ADIF = 0;          // SE APAGA LA BANDERA DEL TMR0.
    return;
}