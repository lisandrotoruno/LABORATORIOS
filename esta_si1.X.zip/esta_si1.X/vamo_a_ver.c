/*
 * File:   I2C_Master_p2.c
 * Author: lisan
 *
 * Created on 27 de mayo de 2022, 11:00 PM
 */

// CONFIG1
#pragma config FOSC = INTRC_NOCLKOUT// Oscillator Selection bits (INTOSCIO oscillator: I/O function on RA6/OSC2/CLKOUT pin, I/O function on RA7/OSC1/CLKIN)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled and can be enabled by SWDTEN bit of the WDTCON register)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config MCLRE = OFF      // RE3/MCLR pin function select bit (RE3/MCLR pin function is digital input, MCLR internally tied to VDD)
#pragma config CP = OFF         // Code Protection bit (Program memory code protection is disabled)
#pragma config CPD = OFF        // Data Code Protection bit (Data memory code protection is disabled)
#pragma config BOREN = OFF      // Brown Out Reset Selection bits (BOR disabled)
#pragma config IESO = OFF       // Internal External Switchover bit (Internal/External Switchover mode is disabled)
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enabled bit (Fail-Safe Clock Monitor is disabled)
#pragma config LVP = OFF        // Low Voltage Programming Enable bit (RB3 pin has digital I/O, HV on MCLR must be used for programming)

// CONFIG2
#pragma config BOR4V = BOR40V   // Brown-out Reset Selection bit (Brown-out Reset set to 4.0V)
#pragma config WRT = OFF        // Flash Program Memory Self Write Enable bits (Write protection off)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

#include <xc.h>
#include <stdint.h>

/*------------------------------------------------------------------------------
 * CONSTANTES 
 ------------------------------------------------------------------------------*/
#define _XTAL_FREQ 8000000          // Frecuencia en la que estamos
#define I2C_SPEED 100000            // La velocidad de comunicaci�n del I2C
#define READ 0b0                    // Bit Lectura I2C
#define WRITE 0b1                   // Bit Escritura I2C 
#define address_s1 0x08             // Direcci�n del Servo1
#define address_s2 0x09             // Direcci�n del Servo2
#define address_s3 0x0A             // Direcci�n del Servo3
#define address_s4 0x0B             // Direcci�n del Servo4

/*------------------------------------------------------------------------------
 * VARIABLES 
 ------------------------------------------------------------------------------*/
uint8_t data = 0, response = 0; //Data de I2C 
uint8_t val_pot1=0, val_pot2=0, val_pot3=0, val_pot4=0; //Manipulaci�n de ADRESH
uint8_t modo = 1;               // El modo comienza por Default con el modo manual (ADC y Guardar posici�n)
uint8_t Entrada;                // Variable que recibe el dato de PC a PIC

/*------------------------------------------------------------------------------
 * PROTOTIPO DE FUNCIONES 
 ------------------------------------------------------------------------------*/
//Prototipo de funcion de configuraciones
void setup(void);

//EEPROM
uint8_t read_EEPROM(uint8_t address);               //Leemos
void write_EEPROM(uint8_t address, uint8_t data);   //Escribimos

//Hab/Deshabilitaci�n de interrupciones
void interupcion_NAN(void);     //Deshabilitamaos la interrupci�n de ADC
void int_Ninterfaz(void);       //Deshabilitamos la interrupci�n de interfaz

void interupcion_AN(void);      // Habilitamos int. de ADC
void int_interfaz(void);        // Habilitamos int. de EUSART

//Prototipo de funci�n para la interfaz
void print(unsigned char palabra);

//Prototipo para la I2C
void wait_I2C(void);            // Esperamos a que termine la de enviar la data
void start_I2C(void);           // Comienzo de comunicaci�n entre PICs
void stop_I2C(void);            // Terminamos comunicaci�n entre PICs
__bit write_I2C(uint8_t data);  // Cargamos el dato a enviar en el Buffer

/*------------------------------------------------------------------------------
 * INTERRUPCIONES 
 ------------------------------------------------------------------------------*/
void __interrupt() isr(void){
    if(INTCONbits.RBIF){                // Fue interrupci�n del PORTB, entonces:
        if(!PORTBbits.RB0){             // cambia modo
            if(modo == 1){      // manual -> reproducci�n
                modo = 2;
            }
            else if(modo == 2){ // reproducci�n -> interfaz
                modo = 4;
            }
            else if(modo == 4){ // interfaz -> manual
                modo = 1;
            }
        }
        PORTD = modo;                   // Mostramos el modo en el puerto D    
        INTCONbits.RBIF = 0;            // Limpiamos bandera 
    }
    else if(modo == 1){                 // Modo Manual
        if(PIR1bits.ADIF){              // BANDERA ADC= ON --> SIGO ADELANTE
    
            if(ADCON0bits.CHS == 0){    // ELIJI� EL CH0?
                val_pot1 = ADRESH;      // Cargamos el valor de ADRESH a la var
                //Para el ancho de pulso
                CCPR1L = (val_pot1>>1)+124;  
                CCP1CONbits.DC1B1 = val_pot1 & 0b01;
                CCP1CONbits.DC1B0 = (val_pot1>>7);
            }
            else if(ADCON0bits.CHS == 1){   // ELIJI� EL CH1?
                val_pot2 = ADRESH;
                //Para el ancho de pulso
                CCPR2L = (val_pot2>>1)+124;   // VALOR == 124
                CCP1CONbits.DC1B1 = val_pot2 & 0b01;
                CCP1CONbits.DC1B0 = (val_pot2>>7);
            }
            else if(ADCON0bits.CHS == 2){   // ELIJI� EL CH2?
                val_pot3 = (ADRESH & 0b11111110); //codificamos para enviar atravez de I2C
            }
            else if(ADCON0bits.CHS == 3){   // ELIJI� EL CH3?
                val_pot4 = ((ADRESH & 0b11111110) | 0b00000001); //codificamos para enviar atravez de I2C
            }
            PIR1bits.ADIF = 0;          // Limpiamos bandera de ADC
        }
        
        else if(INTCONbits.RBIF){       // Fue interrupci�n del PORTB, entonces:
            if(!PORTBbits.RB1){         // Guarda el valor del servo1 
                write_EEPROM(address_s1, val_pot1);     //Escribimos el valor del potenciometro en la direcci�n 
            }
            else if(!PORTBbits.RB2){    // Guarda el valor del servo2 
                write_EEPROM(address_s2, val_pot2);     //Escribimos el valor del potenciometro en la direcci�n 
            }
            INTCONbits.RBIF = 0;        // Limpiamos bandera del POrTB  
        }
    }   
    
    else if(modo == 0b00000010){        // Modo Reproducci�n
        if(INTCONbits.RBIF){            // Fue interrupci�n del PORTB, entonces:
            if(!PORTBbits.RB1){         // Guarda el valor del servo1 
                val_pot1 = read_EEPROM(address_s1);     //Escribimos el valor del potenciometro en la direcci�n 
            }
            else if(!PORTBbits.RB2){    // Guarda el valor del servo2 
                val_pot2 = read_EEPROM(address_s2);     //Escribimos el valor del potenciometro en la direcci�n 
            }
            INTCONbits.RBIF = 0;        // Limpiamos bandera del PORTB  
        }
    }
    
    else if(modo == 0b00000100){        //Modo interfaz
        if(RCIF){                       // Si recibimos datos, entonces:
            Entrada = RCREG;            // Guardamos el valor recibido
            RCREG = 0;                  // RCREG lo seteamos
        }
    }    
    return;
}

/*------------------------------------------------------------------------------
 * CICLO PRINCIPAL
 ------------------------------------------------------------------------------*/
void main(void) {
    setup();
    while(1){                           //Loop Principal
        PORTE = 1;                      //Para comprobar si entra al loop principal
        if(modo == 1){                  //Si es modo manual, entonces:
            int_Ninterfaz();
            interupcion_AN();
            if(GO == 0){    
                if(ADCON0bits.CHS == 0){    //CH0 -> CH1
                    ADCON0bits.CHS = 1;
                }
                else if(ADCON0bits.CHS == 1){    //CH1 -> CH2
                    ADCON0bits.CHS = 2;
                }
                else if(ADCON0bits.CHS == 2){    //CH2 -> CH3
                    ADCON0bits.CHS = 3;
                }
                else if(ADCON0bits.CHS == 3){    //CH3 -> CH0
                    ADCON0bits.CHS = 0;
                }
                PORTE++;                // Verificaci�n para ver si entra en todos los cambios de canal
                GO =1;                  //Comience la conversi�n
            }    
            
            else if(!PORTBbits.RB1){    // Guarda el valor del servo1 
                __delay_ms(100);        // Antirrebote
                write_EEPROM(address_s1, val_pot1);     //Escribimos el valor del potenciometro1 en la direcci�n1 
            }
            else if(!PORTBbits.RB2){    // Guarda el valor del servo2 
                __delay_ms(100);        // Antirrebote
                write_EEPROM(address_s2, val_pot2);     //Escribimos el valor del potenciometro2 en la direcci�n2 
            }
            
            //COMUNICACI�N MAESTRO -> ESCLAVO EN I2C:
           
            //ENVIAMOS EL VALOR DEL POTENCIOMETRO 3
            data = (uint8_t)((address_s3<<1)+READ);
            start_I2C();                // Iniciamos comunicaci�n
            write_I2C(data);            // Enviamos direcci�n de esclavo a recibir datos
            write_I2C(val_pot3);        // Enviamos dato del 3er potenciometro al esclavo 
            stop_I2C();
            
            //ENVIAMOS EL VALOR DEL POTENCIOMETRO 4
            data = (uint8_t)((address_s4<<1)+READ);
            start_I2C();                // Iniciamos comunicaci�n
            write_I2C(data);            // Enviamos direcci�n de esclavo a recibir datos
            write_I2C(val_pot4);        // Enviamos dato del 4to potenciometro al esclavo
            stop_I2C();                 //STOP Y VOLVEMOS A COMUNICAR PARA ENVIAR OTRO DATO
            }
        
        else if(modo == 2){             // Si es modo reproducci�n, entonces:
            interupcion_NAN();          // Deshabilitamos interrupci�n ADC
            int_Ninterfaz();            // Deshabilitamos interrupci�n del EUSART
            if(!PORTBbits.RB1){         // Guarda el valor del servo1 
                __delay_ms(10);         // Antirrebote
                val_pot1 = read_EEPROM(address_s1);     // Leemos el valor del potenciometro de la direcci�n
            }
            else if(!PORTBbits.RB2){    // Guarda el valor del servo2 
                __delay_ms(10);         // Antirrebote
                val_pot2 = read_EEPROM(address_s2);     // Leemos el valor del potenciometro de la direcci�n
            }
            
            //POR LAS DUDAS VOLVEMOS A CODIFICAR LOS VALORES DE POTENCIOMETROS 3 Y 4
            val_pot4 = ((val_pot4 & 0b11111110) | 0b00000001); //codificaci�n 01
            val_pot3 = (val_pot3 & 0b11111110 );             //codificaci�n 00
            //ENVIAMOS EL VALOR DEL POTENCIOMETRO 3 ATRAVEZ DE I2C
            data = (uint8_t)((address_s3<<1)+READ);
            start_I2C();                // Iniciamos comunicaci�n
            write_I2C(data);            // Enviamos direcci�n de esclavo a recibir datos
            write_I2C(val_pot3);        // Enviamos dato del 3er potenciometro al esclavo 
            stop_I2C();
            
            //ENVIAMOS EL VALOR DEL POTENCIOMETRO 4 ATRAVEZ DE I2C
            data = (uint8_t)((address_s4<<1)+READ);
            start_I2C();                // Iniciamos comunicaci�n
            write_I2C(data);            // Enviamos direcci�n de esclavo a recibir datos
            write_I2C(val_pot4);        // Enviamos dato del 4to potenciometro al esclavo
            stop_I2C();                 //STOP Y VOLVEMOS A COMUNICAR PARA ENVIAR OTRO DATO
        }
        
        else if(modo == 4){    // Modo interfaz (no reproduce, ni guarda, solo potenciometros de la interfaz)
            interupcion_NAN();
            if(PIE1bits.RCIE == 0){
                int_interfaz();
            }
            /*
            TMRT para TSR 1 = Vacio y TSR 0 = Ocupado
            TXIF para TXREG 1 = Vacio y TXREG 0 = ocupado
            */
            if((Entrada & 0b00000011) == 0)         // Si el valor recibido es XXXX XX00, entonces:
            {
            val_pot1 = Entrada;         // Entrada guarda el valor del potenciometro 
            print(val_pot1);
            CCPR1L = (val_pot1>>1)+120;
            CCP1CONbits.DC1B1 = val_pot1 & 0b01;
            CCP1CONbits.DC1B0 = (val_pot1>>7);
            }    
            else if((Entrada & 0b00000011) == 1){    // Si el valor recibido es XXXX XX01, entonces:
            val_pot2 = Entrada;         // Entrada guarda el valor del potenciometro 
            print(val_pot2);
            CCPR2L = (val_pot2>>1)+120;   // VALOR == 124
            CCP1CONbits.DC1B1 = val_pot2 & 0b01;
            CCP1CONbits.DC1B0 = (val_pot2>>7);
            }
            else if((Entrada & 0b00000011) == 2){    // Si el valor recibido es XXXX XX10, entonces:
            val_pot3 = Entrada;         // Entrada guarda el valor del potenciometro 
            val_pot3 = (val_pot3 & 0b11111110);       // codificamos XXXX XXX0
            print(val_pot3);
            //ENVIAMOS EL VALOR DEL POTENCIOMETRO 3
            data = (uint8_t)((address_s3<<1)+READ);
            start_I2C();                // Iniciamos comunicaci�n
            write_I2C(data);            // Enviamos direcci�n de esclavo a recibir datos
            write_I2C(val_pot3);        // Enviamos dato del 3er potenciometro al esclavo 
            stop_I2C();                 // Terminamos comunicaci�n para que empiece a enviar otro dato
            }
            else if((Entrada & 0b00000011) == 3){    // Si el valor recibido es XXXX XX11, entonces:
            val_pot4 = Entrada;         // Entrada guarda el valor del potenciometro 
            val_pot4 = ((val_pot4 & 0b11111110) | 0b00000001); // codificamos XXXX XXX1
            print(val_pot4);
            //ENVIAMOS EL VALOR EL POTENCIOMETRO 4
            data = (uint8_t)((address_s4<<1)+READ);
            start_I2C();                // Iniciamos comunicaci�n
            write_I2C(data);            // Enviamos direcci�n de esclavo a recibir datos
            write_I2C(val_pot4);        // Enviamos dato del 4to potenciometro al esclavo
            stop_I2C();                 //STOP Y FINALIZAMOS LA COMUNICACI�N
            }
        }
        else{
            stop_I2C();                 // Finalizamos la comunicaci�n
            PORTD = 0b111;              // Error no hay ningun modo
        }
    }
    return;
}

/*------------------------------------------------------------------------------
 * CONFIGURACION 
 ------------------------------------------------------------------------------*/
void setup(void){       //CONFIGURACIONES     
//---------------------  Config entradas y salidas  ----------------------------
    ANSEL = 0x0F;               // AN0, AN1, AN2 Y AN3 ENTRADAS ANAL�GICAS
    ANSELH = 0;                 // I/O digitales
    
    TRISB = 0x07;               // ENTRADA -> PULSADORES (RB0,RB1,RB2)    
    TRISC = 0;                  // Salida
    TRISD = 0;                  // Salida
    TRISE = 0;                  // Salida
    PORTA = 0;                  // SETEAMOS ALL PORTs 
    PORTB = 0;
    PORTC = 0;
    PORTD = 1;
    PORTE = 0;
    
//-----------------------  Config Reloj (OSCCON))  -----------------------------
    OSCCONbits.SCS  = 1;        // Reloj interno
    OSCCONbits.IRCF = 0b111;    // 8MHz
    
//----------------    Config IOCB (Pull-up internos))  -------------------------
    OPTION_REGbits.nRBPU = 0;
    WPUB = 0b00000111;
    IOCB = 0b00000111;
    
//------  Config ADC ( Fosc/32, justifaci�n izq., Ref Voltajes +5V y 0V))  -----
    ADCON1bits.ADFM = 0; //Justificar a la izquierda
    ADCON1bits.VCFG0 = 0; //Vss
    ADCON1bits.VCFG1 = 0; //VDD
    
    ADCON0bits.ADCS = 0b10; //ADC oscilador -> Fosc/32
    ADCON0bits.CHS = 0;     //Comenzar en primer canal
    __delay_us(50);        
    ADCON0bits.ADON = 1;    //Habilitar la conversi�n ADC
    
//---------  Config PWM (con PR2 de 250, prescaler de 16 del TMR2)  ------------
    //SE USA TMR2 PORQUE USAMOS PWM
    PR2 = 250; //Valor inicial de PR2
    CCP1CONbits.P1M = 0; //PWM bits de salida
    CCP1CONbits.CCP1M = 0b00001100; //Se habilita PWM   
    CCP2CONbits.CCP2M = 0b00001100;   
    
    CCPR1L = 0x0F; 
    CCPR2L = 0x0F;
    CCP1CONbits.DC1B = 0; //Bits menos significativos del Duty Cycle
    CCP2CONbits.DC2B1 = 0;
    CCP2CONbits.DC2B0 = 0;
    
    PIR1bits.TMR2IF = 0; //Se limpia la bandera
    T2CONbits.T2CKPS1 = 1; //Prescaler de 16
    T2CONbits.T2CKPS0 = 1;
    T2CONbits.TMR2ON = 1; //Se enciende el TMR2
    
    while (!PIR1bits.TMR2IF); //Se espera una interrupci�n
    PIR1bits.TMR2IF = 0;      // Limpiamo bandera de TMR2  

//-----  Config EUSART TRANSMITER (9600Baudios, full-duplex, solo 8bits)  -----
    SPBRGH  =   0;              // Byte Superior 9600 Baud Rate
    SPBRG   =   12;             // Byte inferior
    BRGH    =   1;              // Baud rate a alta velocidad
    BRG16   =   1;              // 16bits para generar el baud rate
    TXSTAbits.SYNC = 0;         // Comunicaci�n As�ncrono (full-duplex))
    
    RCSTAbits.SPEN = 1;         // Habilita EUSART y configura como salida a TX/CK 
    TXSTAbits.TXEN = 1;         // Activa circuito para trasmisor del EUSART
    TXSTAbits.TX9  = 0;         // Usamos solo 8 bits
    RCSTAbits.CREN = 1;         // Activa circuito para receptor del EUSART
    
//---- Config I2C (Comunicaci�n a otros dispositivos con 100KHz para que funcione adecuadamente))--- 
    SSPADD = ((_XTAL_FREQ)/(4*I2C_SPEED)) - 1;  // I2C_SPEED de 100 kHz
    SSPSTATbits.SMP = 1;        // Velocidad de rotaci�n
    SSPCONbits.SSPM = 0b1000;   // I2C master mode, clock= Fosc/(4*(SSPADD+1))
    SSPCONbits.SSPEN = 1;       // Habilitamos pines de I2C
    
//---------------------------  Interrupciones  --------------------------------
    PIR1bits.SSPIF = 0;         // Limpiamos bandera de interrupci�n de I2C
    INTCONbits.GIE  = 1;        // Hab. int. generales
    PIE1bits.ADIE = 1;          // Habilitamos interrupcion de ADC
    INTCONbits.PEIE = 1;        // Habilitamos int. de perifericos
    INTCONbits.RBIE = 1;        // Habilitamos int. PORTB
    INTCONbits.RBIF = 0;        // Limpiamos bandera de PORTB
    PIR1bits.ADIF = 0;          // Limpiamos bandera de ADC
}

/*------------------------------------------------------------------------------
 * Funciones 
 ------------------------------------------------------------------------------*/
//----------------------- FUNCIONES DE LA EEPROM -------------------------------
uint8_t read_EEPROM(uint8_t address){ //Modo lectura en la EEPROM
    EEADR = address;            // Guardamos la direcci�n en el valor de direcci�n que tiene (0x10))
    EECON1bits.EEPGD = 0;       // Lectura a la EEPROM
    EECON1bits.RD = 1;          // Obtenemos dato de la EEPROM
    return EEDAT;               // Regresamos dato 
}
void write_EEPROM(uint8_t address, uint8_t data){//Modo escritura en la EEPROM
    EEADR = address;            //Elegimos la direcci�n que vamos a escribir
    EEDAT = data;               //Elegimos el dato que vamos a guardar
    EECON1bits.EEPGD = 0;       // Escritura a la EEPROM
    EECON1bits.WREN = 1;        // Habilitamos escritura en la EEPROM
    
    INTCONbits.GIE = 0;         // Deshabilitamos interrupciones
    EECON2 = 0x55;              //Seg�n el fabricante dice que se tienen que poner estos dos valores en el registro de EECON2
    EECON2 = 0xAA;
    
    EECON1bits.WR = 1;          // Iniciamos escritura
    
    EECON1bits.WREN = 0;        // Deshabilitamos escritura en la EEPROM
    INTCONbits.RBIF = 0;        // Limpiamos bandera de PORTB
    INTCONbits.GIE = 1;         // Habilitamos interrupciones
}

/*******************************************************************************
 * Funciones de ADC
 *******************************************************************************/
void interupcion_NAN(void){     // Deshabilitamos interrupcion del ADC
    PIE1bits.ADIE = 0;          
}
void interupcion_AN(void){      // Habilitamos interrupcion del ADC
    PIE1bits.ADIE = 1;    
}

/*******************************************************************************
 * Funciones del modulo MSSP (I2C)
 *******************************************************************************/
void wait_I2C(void){
    while(!PIR1bits.SSPIF);     // Esperamos a que se ejecute instruccion de I2C
    PIR1bits.SSPIF = 0;         // Limpimos bandera
}
void start_I2C(void){
    SSPCON2bits.SEN = 1;        // Inicializar comunicaci�n, automaticamente se limpia en el hardware
    wait_I2C();                 // Esperamos que se ejecute las intrucciones
}
void stop_I2C(void){
    SSPCON2bits.PEN = 1;        // Finalizar comunicaci�n, automaticamente se limpia en el hardware
    wait_I2C();                 // Esperamos que se ejecute las intrucciones
}
__bit write_I2C(uint8_t data){
    SSPBUF = data;              // Cargar dato a enviar en el buffer
    wait_I2C();                 // Esperamos que se ejecute las intrucciones
    return ACKSTAT;             // Obtener ACK del esclavo
}

/*******************************************************************************
 * Funciones del modulo EUSART
 *******************************************************************************/
void int_Ninterfaz(void){
    PIE1bits.RCIE = 0;          // Deshabilitamos Interrupciones de recepci�n
}
void int_interfaz(void){
    PIE1bits.RCIE = 1;          // Deshabilitamos Interrupciones de recepci�n
}
void print(unsigned char palabra){
    while((palabra) != '\0'){
        while(!TXIF);
        TXREG = (palabra);
        palabra++;
    }    
}