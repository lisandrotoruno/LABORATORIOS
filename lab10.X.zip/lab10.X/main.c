// CONFIGURATION WORDS 1
#pragma config FOSC = INTRC_NOCLKOUT// Oscillator Selection bits (INTOSCIO oscillator: I/O function on RA6/OSC2/CLKOUT pin, I/O function on RA7/OSC1/CLKIN)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled and can be enabled by SWDTEN bit of the WDTCON register)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config MCLRE = OFF      // RE3/MCLR pin function select bit (RE3/MCLR pin function is digital input, MCLR internally tied to VDD)
#pragma config CP = OFF         // Code Protection bit (Program memory code protection is disabled)
#pragma config CPD = OFF        // Data Code Protection bit (Data memory code protection is disabled)
#pragma config BOREN = OFF      // Brown Out Reset Selection bits (BOR disabled)
#pragma config IESO = OFF       // Internal External Switchover bit (Internal/External Switchover mode is disabled)
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enabled bit (Fail-Safe Clock Monitor is disabled)
#pragma config LVP = OFF        // Low Voltage Programming Enable bit (RB3 pin has digital I/O, HV on MCLR must be used for programming)

// CONFIGURATION WORDS 1
#pragma config BOR4V = BOR40V   // Brown-out Reset Selection bit (Brown-out Reset set to 4.0V)
#pragma config WRT = OFF        // Flash Program Memory Self Write Enable bits (Write protection off)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

/*------------------------------------------------------------------------------
 * LIBRERIAS 
 ------------------------------------------------------------------------------*/
#include <xc.h>
#include <stdint.h>
#define _XTAL_FREQ 1000000
/*------------------------------------------------------------------------------
 * VARIABLES 
 ------------------------------------------------------------------------------*/
uint8_t Entrada;            // Variable que donde se va a guardar el val_pot
uint8_t val_pot;            // Var donde guarda el valor de ADRESH
/*------------------------------------------------------------------------------
 * PROTOTIPO DE FUNCIONES 
 ------------------------------------------------------------------------------*/
void setup(void);
void print(unsigned char *palabra);
void enviar_letra(char letra);
void print1n(unsigned char *palabra);
void menusito(void);

/*------------------------------------------------------------------------------
 * INTERRUPCIONES 
 ------------------------------------------------------------------------------*/
void __interrupt() isr (void)
{
    if(ADCON0bits.CHS == 0)         // Si estamos en el canal 0,entonces:
    {
        val_pot = ADRESH;           // Guardamos el valor del potenciometro
    }
    PIR1bits.ADIF = 0;              // Limpiamos bandera de interrupci�n
    
    if(RCIF)                        // Si recibimos datos, entonces:
    {
        Entrada = RCREG;            // Guardamos el valor recibido
        RCREG = 0;                  // RCREG lo seteamos
    }
}
/*------------------------------------------------------------------------------
 * CICLO PRINCIPAL
 -----------------------------------------------------------------------------*/
void main(void) 
{
    setup();                        // Config inicial
    menusito();
    while(1)                        // Loop Principal
    {
        if(GO == 0)                 // No hay proceso de conversi�n
        {
            GO = 1;                 // Comienza a convertir ADC 
        }    
        /*
         TMRT para TSR 1 = Vacio y TSR 0 = Ocupado
         TXIF para TXREG 1 = Vacio y TXREG 0 = ocupado
         */
        if(Entrada == 0x31)         // Si el valor recibido es '1', entonces:
        {
            print1n("Leer el potenciometro:");  
            print1n("");
            menusito();             // Muestra en la terminal que opci�n elegir
            Entrada = val_pot;      // Entrada guarda el valor del potenciometro              
        }    
        
        else if(Entrada == 0x32)    // Si el valor recibido es '2', entonces:
        {
          print1n("Mostrar el ASCII en PORTB:");    
          Entrada = 0;              
          while(Entrada == 0);
          PORTB = val_pot;          // el valor que muestra en el PORTB es el valor del potenciometro
          menusito();               // Muestra la terminal de que opci�n elegir
        }    
    }    
}
/*------------------------------------------------------------------------------
 * CONFIGURACION 
 ------------------------------------------------------------------------------*/
void setup(void)
{
    //Config de I/O
    ANSEL  = 0b00000001;         // AN0 es entrada anal�gica
    ANSELH = 0;                  // I/O digitales
    TRISB  = 0;                  // SALIDA
    PORTA  = 0;                  // Seteo a todos los puertos
    PORTB  = 0;
    PORTC  = 0;
    PORTE  = 0;
    
    //Config Reloj
    OSCCONbits.SCS  = 1;        // Reloj interno
    OSCCONbits.IRCF = 0b100;    // 1MHz
    
    //Config ADC
    ADCON0bits.ADCS = 0b01;     // Fosc/8
    ADCON1bits.VCFG0 = 0;       // VDD
    ADCON1bits.VCFG1 = 0;       // VSS
    ADCON0bits.CHS = 0b0000;    // Seleccionamos el AN0
    ADCON1bits.ADFM = 0;        // Justificado a la izquierda
    ADCON0bits.ADON = 1;        // Habilitamos modulo ADC
    __delay_us(40);             // Sample time
    
    //Config INTERRUPCIONES
    INTCONbits.GIE  = 1;        // Hab. int. generales
    INTCONbits.PEIE = 1;        // Hab. int. perifericas
    PIE1bits.ADIE = 1;          // Habilitamos interrupcion de ADC
    PIR1bits.ADIF = 0;          // Limpiamos bandera de ADC
    
    //Config EUSART TRANSMITER
    SPBRGH  =   0;              // Byte Superior 9600 Baud Rate
    SPBRG   =   25;             // Byte inferior
    BRGH    =   1;
    BRG16   =   1;
    
    TXSTAbits.SYNC = 0;         // As�ncrono
    RCSTAbits.SPEN = 1;         // Habilita EUSART y configura como salida a TX/CK 
    TXSTAbits.TXEN = 1;         // Activa circuito para trasmisor del EUSART
    RCSTAbits.CREN = 1;         // Activa circuito para receptor del EUSART
    PIE1bits.RCIE  = 1;         // Es la interrupci�n de receptor
}

void print(unsigned char *palabra)
{
    while((*palabra) != '\0')   // Si no es '0', entonces
    {
        while(!TXIF);           // Se mantiene en bucle si TXIF es 0
        TXREG = (*palabra);     // TXREG es palabra
        *palabra++;             // palabra aumenta en 1
    }    
}

void print1n(unsigned char *palabra)
{
    while((*palabra) != '\0')   
    {
        while(!TXIF);
        TXREG = (*palabra);
        *palabra++;
    }    
    enviar_letra('\r');         
}

void enviar_letra(char letra)
{
    while(!TXIF);              // 
    TXREG = letra;
}

void menusito(void)
{
    print1n("");
    print1n("");
    print1n("�Qu� acci�n desea ejecutar?");
    print1n("(1)  Leer el potenciometro ");
    print1n("(2)  Enviar ASCII          ");
    print1n("");
    print1n("");
}